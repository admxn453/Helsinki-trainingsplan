# Helsinki Trainingsplan – installierbare PWA

## Dateien
- `index.html`: dein ursprünglicher Trainingskalender mit PWA-Einbindung
- `manifest.webmanifest`: Name, Icon und Installationsdarstellung
- `service-worker.js`: Cache für Offline-Start und App-Dateien
- `icons/`: App-Symbole

## Wichtig
Eine PWA muss über HTTPS (oder localhost) aufgerufen werden. Das Öffnen der HTML-Datei direkt aus dem Dateimanager reicht nicht für die Installation als PWA.

## Einfacher Veröffentlichungsweg: GitHub Pages
1. Melde dich bei GitHub an und erstelle ein neues Repository, z. B. `helsinki-trainingsplan`.
2. Lade den Inhalt dieses ZIP-Archivs in das Repository hoch. `index.html` muss direkt im Hauptverzeichnis liegen.
3. Öffne im Repository **Settings → Pages**.
4. Wähle **Deploy from a branch**, Branch `main`, Ordner `/ (root)` und speichere.
5. Warte, bis GitHub Pages eine HTTPS-Adresse anzeigt.
6. Öffne diese Adresse auf deinem Android-Handy in Chrome.
7. Tippe auf **⋮ → App installieren** (oder **Zum Startbildschirm hinzufügen**, falls Chrome diese Option anbietet).

## Datenspeicherung
Der Kalender speichert Änderungen lokal im Browser-Speicher dieses Geräts und dieser Website-Adresse. Browserdaten nicht löschen, wenn du deine Einträge behalten willst. Die ursprüngliche Claude-Cloud-Synchronisierung ist außerhalb der Claude-Umgebung nicht verfügbar; der Kalender zeigt deshalb gegebenenfalls weiterhin nur lokale Speicherung an. Für Synchronisierung zwischen Geräten wäre ein eigener Backend-Dienst nötig.

## Hinweise
- Der Offline-Cache speichert die App-Dateien. Externe Google Fonts benötigen beim ersten Laden eine Internetverbindung.
- Wenn du später Dateien änderst, erhöhe in `service-worker.js` den Cache-Namen (z. B. auf `v2`), damit Geräte die neue Version übernehmen.
